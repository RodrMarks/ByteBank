## BYTEBANK'S CAIXA PRETA


1) Oque é necessario para rodar o ByteBank:

- É preciso ter o nodejs e npm instalados na maquina.
- Rodar o comando `npm run start` para iniciar o projeto.
- Rodar o comando `npm install` para instalar as dependencias.
- Rodar o comando `npm install express` para definir rotas, lidar com requisições e respostas HTTP, e configurar middlewares.
- Rodar o comando `npm install cpf-check` para verificar se um número de CPF é valido.
- Rodar o comando `npm install cpf-validator` para validação de CPFs, fornecendo métodos para verificar a validade e formatar números de CPF.
- Rodar o comando `node main.js` para iniciar a porta 8080.
## PROCESSOS DE SEGURANÇA DO BYTEBANK
- Rodar o comando `express-rate-limit`para limitar a taxa de solicitações recebidas de um mesmo IP,ajuda a evitar ataques de força bruta e proteger contra abusos.
- Rodar o comando `npm install helmet` ajuda a proteger a aplicação Express configurando vários cabeçalhos HTTP relacionados à segurança.


2) Duvidas durante o projeto sobre o desafio proposto:

-  "O processo deve reverter a transação original sem levar nenhuma conta envolvida a um saldo negativo" , mas e se apos a transacao espeficica tiverem havido outras, devemos analisar o impacto dela nessas outras?

`como acho que deve ser resolvido: Sobre o cancelamento, acredito que é necessario analisar o impacto dela nas outras, acredito que o objetivo seja preservar a integridade das operações`

- como fica a questão do saldo da conta atual, e o saldo nas operacoes sequentes que ja existiam?

`a questão do saldo, após cancelar uma transação, o saldo da conta deve ser recalculado considerando as transações não anuladas, garantindo que reflita todas as operações válidas, as operações seguintes continuam a afetar o saldo normalmente`



3) OBSERVAÇÕES: 

- No requisito da criação de conta `Cada CPF pode ter apenas uma conta de cada tipo (corrente, poupança, salário)` eu entendi que um mesmo cpf pode ter uma conta corrente, uma conta poupança e uma conta salário, mas não pode ter duas contas correntes, por exemplo. - No cpf é pedido para colocar um valido e formatado, entao eu coloquei uma lib para validar o cpf e criei uma função para parsear o cpf caso ele venha formatado com ponto e traço.