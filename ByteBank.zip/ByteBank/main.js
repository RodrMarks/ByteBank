const express = require('express');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const { ControladorCriarConta } = require('./controladores/criarConta');
const { ControladorListarContas } = require('./controladores/listarContas');
const { ControladorRetornarConta } = require('./controladores/retornarConta');
const { ControladorAtualizarConta } = require('./controladores/atualizarConta');
const { ControladorEncerrarConta } = require('./controladores/encerrarConta');
const { ControladorDepositar } = require('./controladores/depositar');
const { ControladorSacar } = require('./controladores/sacar');
const { ControladorTransferir } = require('./controladores/transferir');
const { ControladorExtrato } = require('./controladores/extrato');
const { ControladorCancelarOperacao } = require('./controladores/cancelarOperacao');

const app = express();

// Configuração do limite de taxa
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 5, // Permitir 5 tentativas
  message: 'Muitas tentativas de login a partir deste IP, tente novamente após 15 minutos.'
});

// Aplicar o middleware de limite de taxa a todas as rotas que precisam de proteção
app.use('/contas/:idConta', limiter);

// Adicionar o middleware do helmet
app.use(helmet());

app.disable('x-powered-by');
app.use(express.json());

app.post('/contas', ControladorCriarConta);
app.get('/contas', ControladorListarContas);
app.get('/contas/:idConta', ControladorRetornarConta);
app.put('/contas/:idConta', ControladorAtualizarConta);
app.delete('/contas/:idConta', ControladorEncerrarConta);

app.post('/contas/:idConta/depositar', ControladorDepositar);
app.post('/contas/:idConta/sacar', ControladorSacar);
app.post('/contas/:idConta/transferir', ControladorTransferir);
app.get('/contas/:idConta/extrato', ControladorExtrato);
app.delete('/transacoes/:idTransacao/cancelar', ControladorCancelarOperacao);

const PORT = 8080;

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});