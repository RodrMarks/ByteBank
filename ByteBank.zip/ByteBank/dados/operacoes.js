const fs = require('fs/promises');

const ARQUIVO_OPERACOES = 'dados/extratos_banco.json';
const ARQUIVO_OPERACOES_CANCELADAS = 'dados/transacoes_canceladas_banco.json';

const adicionarOperacao = async (idTransacao, dataTransacao, tipoTransacao, valor, saldoAposTransacao, idContaOrigem, idContaDestino) => {
    try {
        const dadosAntigos = await fs.readFile(ARQUIVO_OPERACOES, 'utf8');
        const operacoes = JSON.parse(dadosAntigos);

        operacoes.push({ idTransacao, dataTransacao, tipoTransacao, valor, saldoAposTransacao, idContaOrigem, idContaDestino });

        await fs.writeFile(ARQUIVO_OPERACOES, JSON.stringify(operacoes, null, 2));

        return { idTransacao, dataTransacao, tipoTransacao, valor, saldoAposTransacao, idContaOrigem, idContaDestino };
    } catch (error) {
        console.error(error.message);
        throw new Error('Erro ao adicionar a operação');
    }
};

const extrato = async (idConta) => {
    try {
        const dadosAntigos = await fs.readFile(ARQUIVO_OPERACOES, 'utf8');
        const operacoes = JSON.parse(dadosAntigos);

        const extrato = operacoes.filter((operacao) => operacao.idContaOrigem === idConta || operacao.idContaDestino === idConta);

        return extrato;
    } catch (error) {
        console.error(error.message);
        throw new Error('Erro ao adicionar a operação');
    }
}

const retornarOperacao = async (idTransacao) => {
    try {
        const dadosAntigos = await fs.readFile(ARQUIVO_OPERACOES, 'utf8');
        const operacoes = JSON.parse(dadosAntigos);

        const operacaoEncontrada = operacoes.find((operacao) => operacao.idTransacao === idTransacao);

        return operacaoEncontrada;
    } catch (error) {
        console.error(error.message);
        throw new Error('Erro ao adicionar a operação');
    }
}

const removerOperacao = async (idTransacao) => {
    try {
        const dadosAntigos = await fs.readFile(ARQUIVO_OPERACOES, 'utf8');
        const operacoes = JSON.parse(dadosAntigos);

        const operacoesFiltradas = operacoes.filter((operacao) => operacao.idTransacao !== idTransacao);

        await fs.writeFile(ARQUIVO_OPERACOES, JSON.stringify(operacoesFiltradas, null, 2));
    } catch (error) {
        console.error(error.message);
        throw new Error('Erro ao adicionar a operação');
    }
}

const adicionarOperacaoCancelada = async (idTransacao, dataTransacao, tipoTransacao, valor, saldoAposTransacao, idContaOrigem, idContaDestino) => {
    try {
        const dadosAntigos = await fs.readFile(ARQUIVO_OPERACOES_CANCELADAS, 'utf8');
        const operacoes = JSON.parse(dadosAntigos);

        operacoes.push({ idTransacao, dataTransacao, tipoTransacao, valor, saldoAposTransacao, idContaOrigem, idContaDestino });

        await fs.writeFile(ARQUIVO_OPERACOES_CANCELADAS, JSON.stringify(operacoes, null, 2));

        return { idTransacao, dataTransacao, tipoTransacao, valor, saldoAposTransacao, idContaOrigem, idContaDestino };
    } catch (error) {
        console.error(error.message);
        throw new Error('Erro ao adicionar a operação');
    }
}

const atualizarOperacao = async (idTransacao, saldoAposTransacao) => {
    try {
        const dadosAntigos = await fs.readFile(ARQUIVO_OPERACOES, 'utf8');
        const operacoes = JSON.parse(dadosAntigos);

        const operacaoEncontrada = operacoes.findIndex((operacao) => operacao.idTransacao === idTransacao);

        if (operacaoEncontrada === -1) {
            throw new Error('Operação não encontrada');
        }

        operacoes[operacaoEncontrada].saldoAposTransacao = saldoAposTransacao;

        await fs.writeFile(ARQUIVO_OPERACOES, JSON.stringify(operacoes, null, 2));
    } catch (error) {
        console.error(error.message);
        throw new Error('Erro ao adicionar a operação');
    }
}

module.exports = { adicionarOperacao, extrato, retornarOperacao, removerOperacao, adicionarOperacaoCancelada, atualizarOperacao };