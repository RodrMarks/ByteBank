const fs = require('fs/promises');

const ARQUIVO_CONTAS = 'dados/contas_banco.json';

const adicionarConta = async (idConta, nomeTitular, cpfTitular, tipoConta, saldo, statusConta, numeroConta, agencia) => {
    try {
        const dadosAntigos = await fs.readFile(ARQUIVO_CONTAS, 'utf8');
        const contas = JSON.parse(dadosAntigos);

        const status = statusConta
        contas.push({ idConta, nomeTitular, cpfTitular, numeroConta, agencia, tipoConta, saldo, status });

        await fs.writeFile(ARQUIVO_CONTAS, JSON.stringify(contas, null, 2));

        return { idConta, nomeTitular, cpfTitular, numeroConta, agencia, tipoConta, saldo, status };
    } catch (error) {
        console.error(error.message);
        throw new Error('Erro ao adicionar a conta');
    }
};

const listarContas = async () => {
    try {
        const dadosAntigos = await fs.readFile(ARQUIVO_CONTAS, 'utf8');
        const contas = JSON.parse(dadosAntigos);

        return contas;
    } catch (error) {
        console.error(error.message);
        throw new Error('Erro ao listar as contas');
    }
};

const retornarConta = async (idConta) => {
    try {
        const dadosAntigos = await fs.readFile(ARQUIVO_CONTAS, 'utf8');
        const contas = JSON.parse(dadosAntigos);

        const conta = contas.find((conta) => conta.idConta === idConta);

        return conta;
    } catch (error) {
        console.error(error.message);
        throw new Error('Erro ao retornar a conta');
    }
};

const filtrarContasPorCpfETipo = async (cpfTitular, tipoConta) => {
    try {
        const dadosAntigos = await fs.readFile(ARQUIVO_CONTAS, 'utf8');
        const contas = JSON.parse(dadosAntigos);

        const contasFiltradas = contas.filter((conta) => conta.cpfTitular === cpfTitular && conta.tipoConta === tipoConta);

        return contasFiltradas;
    } catch (error) {
        console.error(error.message);
        throw new Error('Erro ao filtrar contas por CPF e tipo');
    }
}

const atualizarConta = async (idConta, novoNomeTitular, novoCpfTitular, novoStatus, novoSaldo) => {
    try {
        const dadosAntigos = await fs.readFile(ARQUIVO_CONTAS, 'utf8');
        const contas = JSON.parse(dadosAntigos);

        const indice = contas.findIndex((conta) => conta.idConta === idConta);

        if (indice === -1) {
            throw new Error('Conta não encontrada');
        }

        let { nomeTitular, cpfTitular, numeroConta, agencia, tipoConta, saldo, status } = contas[indice];

        if (novoNomeTitular !== undefined && novoNomeTitular !== "") {
            nomeTitular = novoNomeTitular;
        }
        if (novoCpfTitular !== undefined && novoCpfTitular !== "") {
            cpfTitular = novoCpfTitular;
        }
        if (novoStatus !== undefined && novoStatus !== "") {
            status = novoStatus;
        }
        if (novoSaldo !== undefined && novoSaldo !== "") {
            saldo = novoSaldo;
        }

        contas[indice] = { idConta, nomeTitular, cpfTitular, numeroConta, agencia, tipoConta, saldo, status };

        await fs.writeFile(ARQUIVO_CONTAS, JSON.stringify(contas, null, 2));

        return { idConta, nomeTitular, cpfTitular, numeroConta, agencia, tipoConta, saldo, status };
    } catch (error) {
        console.error(error.message);
        throw new Error('Erro ao atualizar a conta');
    }

}

module.exports = { adicionarConta, filtrarContasPorCpfETipo, listarContas, retornarConta, atualizarConta };