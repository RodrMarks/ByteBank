const gerarId = (n) => {
    const caracteres = '0123456789';
    let id = '';

    for (let i = 0; i < n; i++) {
        const indiceAleatorio = Math.floor(Math.random() * caracteres.length);
        id += caracteres.charAt(indiceAleatorio);
    }

    return id;
};

const gerarIdConta = () => {
    return gerarId(10);
};

const gerarIdOperacao = () => {
    return gerarId(15);
};

const gerarNumeroConta = () => {
    return gerarId(6);
};

const gerarAgencia = () => {
    return gerarId(4);
}

const removerNaoNumericos = (s) => {
    return s.replace(/\D/g, '');
}

module.exports = { gerarId, gerarIdConta, gerarNumeroConta, gerarAgencia, gerarIdOperacao, removerNaoNumericos };
