const { listarContas } = require('../dados/contas');

const ControladorListarContas = async (req, res) => {
    try {
        const contas = await listarContas();

        res.status(200).json(contas);
    } catch (error) {
        res.status(500).json({ error: error.message || 'Erro interno do servidor' });
    }
};

module.exports = { ControladorListarContas };