const { adicionarConta, filtrarContasPorCpfETipo } = require('../dados/contas');
const { gerarIdConta, gerarAgencia, gerarNumeroConta, removerNaoNumericos } = require('../utils');
const cpfCheck = require('cpf-check');

const ControladorCriarConta = async (req, res) => {
    try {
        let { nomeTitular, cpfTitular, tipoConta } = req.body;

        if (!nomeTitular || !cpfTitular || !tipoConta) {
            return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
        }

        if (tipoConta !== 'corrente' && tipoConta !== 'poupança' && tipoConta !== 'salario') {
            return res.status(400).json({ error: 'Tipo de conta inválido' });
        }

        cpfTitular = removerNaoNumericos(cpfTitular);

        if (!cpfCheck.validate(cpfTitular)) {
            return res.status(400).json({ error: 'CPF invalido' });
        }

        contas = await filtrarContasPorCpfETipo(cpfTitular, tipoConta);
        if (contas.length >= 1) {
            return res.status(400).json({ error: 'CPF já cadastrado para o tipo de conta' });
        }

        saldoConta = 0
        statusConta = 'ativa'
        idConta = gerarIdConta();
        numeroConta = gerarNumeroConta();
        agencia = gerarAgencia();

        const dadosCriados = await adicionarConta(idConta, nomeTitular, cpfTitular, tipoConta, saldoConta, statusConta, numeroConta, agencia);

        res.status(200).json(dadosCriados);
    } catch (error) {
        res.status(500).json({ error: error.message || 'Erro interno do servidor' });
    }
};

module.exports = { ControladorCriarConta };