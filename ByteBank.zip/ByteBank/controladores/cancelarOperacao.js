const { adicionarOperacaoCancelada, extrato, retornarOperacao, removerOperacao, atualizarOperacao } = require('../dados/operacoes');
const { retornarConta, atualizarConta } = require('../dados/contas');

const ControladorCancelarOperacao = async (req, res) => {
    try {
        const { idTransacao } = req.params;

        const operacaoEncontrada = await retornarOperacao(idTransacao);

        if (!operacaoEncontrada) {
            return res.status(404).json({ mensagem: 'Operação não encontrada' });
        }

        if (operacaoEncontrada.tipoTransacao === 'TRANSFERENCIA') {
            const contaOrigem = await retornarConta(operacaoEncontrada.idContaOrigem);
            const contaDestino = await retornarConta(operacaoEncontrada.idContaDestino);

            if (!contaOrigem || !contaDestino) {
                return res.status(404).json({ mensagem: 'Conta não encontrada' });
            }

            if (contaOrigem.status !== 'ativa' || contaDestino.status !== 'ativa') {
                return res.status(400).json({ mensagem: 'Conta não ativa' });
            }

            const extratoOrigem = await extrato(contaOrigem.idConta);
            const extratoDestino = await extrato(contaDestino.idConta);

            const [sucessoOrigem, saldoFinalOrigem, modificacoesOrigem] = algoritmo(extratoOrigem, operacaoEncontrada, contaOrigem.idConta);
            const [sucessoDestino, saldoFinalDestino, modificacoesDestino] = algoritmo(extratoDestino, operacaoEncontrada, contaDestino.idConta);

            if (!sucessoOrigem || !sucessoDestino) {
                return res.status(400).json({ mensagem: 'Não foi possível cancelar a operação' });
            }

            await adicionarOperacaoCancelada(operacaoEncontrada.idTransacao, operacaoEncontrada.dataTransacao, operacaoEncontrada.tipoTransacao, operacaoEncontrada.valor, operacaoEncontrada.saldoAposTransacao, operacaoEncontrada.idContaOrigem, operacaoEncontrada.idContaDestino);
            await removerOperacao(operacaoEncontrada.idTransacao);

            for (let i = 0; i < modificacoesOrigem.length; i++) {
                await atualizarOperacao(modificacoesOrigem[i].idTransacao, modificacoesOrigem[i].saldoAposTransacao);
            }
            for (let i = 0; i < modificacoesDestino.length; i++) {
                await atualizarOperacao(modificacoesDestino[i].idTransacao, modificacoesDestino[i].saldoAposTransacao);
            }

            await atualizarConta(contaOrigem.idConta, undefined, undefined, undefined, saldoFinalOrigem);
            await atualizarConta(contaDestino.idConta, undefined, undefined, undefined, saldoFinalDestino);
        } else {
            const idConta = operacaoEncontrada.tipoTransacao === 'DEPOSITO' ? operacaoEncontrada.idContaDestino : operacaoEncontrada.idContaOrigem;

            const conta = await retornarConta(idConta);

            if (!conta) {
                return res.status(404).json({ mensagem: 'Conta não encontrada' });
            }

            if (conta.status !== 'ativa') {
                return res.status(400).json({ mensagem: 'Conta não ativa' });
            }

            const extratoConta = await extrato(conta.idConta);

            const [sucesso, saldoFinal, modificacoes] = algoritmo(extratoConta, operacaoEncontrada, conta.idConta);

            if (!sucesso) {
                return res.status(400).json({ mensagem: 'Não foi possível cancelar a operação' });
            }

            await adicionarOperacaoCancelada(operacaoEncontrada.idTransacao, operacaoEncontrada.dataTransacao, operacaoEncontrada.tipoTransacao, operacaoEncontrada.valor, operacaoEncontrada.saldoAposTransacao, operacaoEncontrada.idContaOrigem, operacaoEncontrada.idContaDestino);
            await removerOperacao(operacaoEncontrada.idTransacao);

            for (let i = 0; i < modificacoes.length; i++) {
                await atualizarOperacao(modificacoes[i].idTransacao, modificacoes[i].saldoAposTransacao);
            }

            await atualizarConta(conta.idConta, undefined, undefined, undefined, saldoFinal);
        }

        res.status(200).json({ message: `Transação com ID ${idTransacao} cancelada com sucesso.` });
    } catch (error) {
        res.status(500).json({ mensagem: error.message });
    }
}

function algoritmo(extrato, operacao, idConta) {
    extrato.sort((a, b) => new Date(b.dataTransacao) - new Date(a.dataTransacao));
    
    let operacoesPosteriores = []
    for (let i = 0; i < extrato.length; i++) {
        if (extrato[i].idTransacao === operacao.idTransacao) {
            break;
        }
        operacoesPosteriores.push(extrato[i]);
    }
    
    let saldo = 0;
    if (operacao.tipoTransacao === 'DEPOSITO') {
        saldo = operacao.saldoAposTransacao - operacao.valor;
    }
    else if (operacao.tipoTransacao === 'SAQUE') {
        saldo = operacao.saldoAposTransacao + operacao.valor;
    }
    else if (operacao.tipoTransacao === 'TRANSFERENCIA') {
        if (idConta === operacao.idContaOrigem) {
            saldo = operacao.saldoAposTransacao + operacao.valor;
        }
        else if (idConta === operacao.idContaDestino) {
            for (let i = 0; i < extrato.length; i++) {
                if (extrato[i].idTransacao === operacao.idTransacao) {
                    if (i + 1 < extrato.length && extrato[i + 1].tipoTransacao !== 'TRANSFERENCIA') {
                        if (extrato[i + 1].tipoTransacao === 'DEPOSITO' || extrato[i + 1].tipoTransacao === 'SAQUE') {
                            saldo = extrato[i + 1].saldoAposTransacao;
                        }
                    } else if (i + 1 < extrato.length && extrato[i + 1].tipoTransacao === 'TRANSFERENCIA') {
                        if (extrato[i + 1].idContaOrigem === idConta) {
                            saldo = extrato[i + 1].saldoAposTransacao;
                        } else {
                            let recebiveis = 0;
                            let saldoCalculdado = false;
                            for (let j = i + 1; j < extrato.length; j++) {
                                if (extrato[j].tipoTransacao === 'TRANSFERENCIA' && extrato[j].idContaDestino === idConta) {
                                    recebiveis += extrato[j].valor;
                                } else {
                                    saldo = extrato[j].saldoAposTransacao - recebiveis;
                                    saldoCalculdado = true;
                                    break;
                                }
                            }
                            if (!saldoCalculdado) {
                                saldo = recebiveis;
                            }
                        }
                    }
                    break;
                }
            }
        }
    }

    operacoesPosteriores.sort((a, b) => new Date(a.dataTransacao) - new Date(b.dataTransacao));
    
    let saldoDavez = 0;
    let modificacoes = [];
    for (let i = 0; i < operacoesPosteriores.length; i++) {
        if (operacoesPosteriores[i].tipoTransacao === 'DEPOSITO') {
            saldoDavez = saldo + operacoesPosteriores[i].valor;
            modificacoes.push({ idTransacao: operacoesPosteriores[i].idTransacao, saldoAposTransacao: saldoDavez })
        }
        else if (operacoesPosteriores[i].tipoTransacao === 'SAQUE') {
            saldoDavez = saldo - operacoesPosteriores[i].valor;
            modificacoes.push({ idTransacao: operacoesPosteriores[i].idTransacao, saldoAposTransacao: saldoDavez })
        }
        else if (operacoesPosteriores[i].tipoTransacao === 'TRANSFERENCIA') {
            if (idConta === operacoesPosteriores[i].idContaOrigem) {
                saldoDavez = saldo - operacoesPosteriores[i].valor;
                modificacoes.push({ idTransacao: operacoesPosteriores[i].idTransacao, saldoAposTransacao: saldoDavez })
            }
            else if (idConta === operacoesPosteriores[i].idContaDestino) {
                saldoDavez = saldo + operacoesPosteriores[i].valor;
            }
        }
        if (saldoDavez < 0) {
            return [false, undefined, undefined];
        }
        saldo = saldoDavez;
    }

    return [true, saldo, modificacoes];
}

module.exports = { ControladorCancelarOperacao };