const { retornarConta } = require('../dados/contas');

const ControladorRetornarConta = async (req, res) => {
    try {
        const { idConta } = req.params;

        const conta = await retornarConta(idConta);

        if (!conta) {
            return res.status(404).json({ error: 'Conta não encontrada' });
        }

        res.status(200).json(conta);
    } catch (error) {
        res.status(500).json({ error: error.message || 'Erro interno do servidor' });
    }
}

module.exports = { ControladorRetornarConta };