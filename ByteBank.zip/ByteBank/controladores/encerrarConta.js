const { atualizarConta } = require('../dados/contas');

const ControladorEncerrarConta = async (req, res) => {
    const { idConta } = req.params;

    try {
        const conta = await atualizarConta(idConta, undefined, undefined, 'encerrada', undefined);

        return res.status(200).json({ message: `Conta com ID ${idConta} foi encerrada com sucesso.` });
    } catch (error) {
        res.status(500).json({ mensagem: error.message });
    }
}

module.exports = { ControladorEncerrarConta };