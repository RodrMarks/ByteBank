const { atualizarConta, retornarConta } = require('../dados/contas');
const { adicionarOperacao } = require('../dados/operacoes');
const { gerarIdOperacao } = require('../utils');

const TIPO_TRANSACAO = 'DEPOSITO';

const ControladorDepositar = async (req, res) => {
    try {
        const { idConta } = req.params;
        const { valor } = req.body;

        if (!valor || !idConta) {
            return res.status(400).json({ mensagem: 'Todos os campos são obrigatorios' });
        }

        if (valor <= 0) {
            return res.status(400).json({ mensagem: 'O campo "valor" deve ser maior que zero' });
        }

        const contaEncontrada = await retornarConta(idConta);

        if (!contaEncontrada) {
            return res.status(404).json({ mensagem: 'Conta não encontrada' });
        }
        if (contaEncontrada.status !== 'ativa') {
            return res.status(400).json({ mensagem: 'Conta não ativa' });
        }

        const novoSaldo = contaEncontrada.saldo + valor;

        await atualizarConta(idConta, undefined, undefined, undefined, novoSaldo);

        const idTransacao = gerarIdOperacao();
        const dataTransacao = new Date().toISOString();
        const tipoTransacao = TIPO_TRANSACAO;
        const saldoAposTransacao = novoSaldo;
        const idContaOrigem = null;
        const idContaDestino = idConta;

        await adicionarOperacao(idTransacao, dataTransacao, tipoTransacao, valor, saldoAposTransacao, idContaOrigem, idContaDestino);

        res.status(200).json({ idConta, saldoAtual: novoSaldo });
    } catch (error) {
        res.status(500).json({ mensagem: error.message });
    }
}

module.exports = { ControladorDepositar };