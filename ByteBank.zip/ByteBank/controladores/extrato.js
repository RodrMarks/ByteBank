const { retornarConta } = require('../dados/contas');
const { extrato } = require('../dados/operacoes');

const ControladorExtrato = async (req, res) => {
    try {
        const { idConta } = req.params;

        const contaEncontrada = await retornarConta(idConta);

        if (!contaEncontrada) {
            return res.status(404).json({ mensagem: 'Conta não encontrada' });
        }

        if (contaEncontrada.status !== 'ativa') {
            return res.status(400).json({ mensagem: 'Conta não ativa' });
        }

        let extratoConta = await extrato(idConta);

        extratoConta.sort((a, b) => new Date(b.dataTransacao) - new Date(a.dataTransacao));

        res.status(200).json(extratoConta);
    } catch (error) {
        res.status(500).json({ mensagem: error.message });
    }
}

module.exports = { ControladorExtrato };