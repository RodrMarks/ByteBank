const { atualizarConta, retornarConta } = require('../dados/contas');
const { adicionarOperacao } = require('../dados/operacoes');
const { gerarIdOperacao } = require('../utils');

const TIPO_TRANSACAO = 'TRANSFERENCIA';

const ControladorTransferir = async (req, res) => {
    try {
        const { idConta } = req.params;
        const { idContaDestino, valor } = req.body;

        if (!valor || !idConta || !idContaDestino) {
            return res.status(400).json({ mensagem: 'Todos os campos são obrigatorios' });
        }

        if (valor <= 0) {
            return res.status(400).json({ mensagem: 'O campo "valor" deve ser maior que zero' });
        }

        const contaOrigemEncontrada = await retornarConta(idConta);

        if (!contaOrigemEncontrada) {
            return res.status(404).json({ mensagem: 'Conta origem não encontrada' });
        }
        if (contaOrigemEncontrada.status !== 'ativa') {
            return res.status(400).json({ mensagem: 'Conta origem não ativa' });
        }
        if (contaOrigemEncontrada.saldo < valor) {
            return res.status(400).json({ mensagem: 'Saldo insuficiente' });
        }

        const contaDestinoEncontrada = await retornarConta(idContaDestino);

        if (!contaDestinoEncontrada) {
            return res.status(404).json({ mensagem: 'Conta destino não encontrada' });
        }

        if (contaDestinoEncontrada.status !== 'ativa') {
            return res.status(400).json({ mensagem: 'Conta destino não ativa' });
        }

        const novoSaldoContaOrigem = contaOrigemEncontrada.saldo - valor;
        const novoSaldoContaDestino = contaDestinoEncontrada.saldo + valor;

        await atualizarConta(idConta, undefined, undefined, undefined, novoSaldoContaOrigem);
        await atualizarConta(idContaDestino, undefined, undefined, undefined, novoSaldoContaDestino);

        const idTransacao = gerarIdOperacao();
        const dataTransacao = new Date().toISOString();
        const tipoTransacao = TIPO_TRANSACAO;
        const saldoAposTransacao = novoSaldoContaOrigem;
        const idContaOrigem = idConta;

        await adicionarOperacao(idTransacao, dataTransacao, tipoTransacao, valor, saldoAposTransacao, idContaOrigem, idContaDestino);

        res.status(200).json({ idConta, saldoAtual: novoSaldoContaOrigem });
    } catch (error) {
        res.status(500).json({ mensagem: error.message });
    }
}

module.exports = { ControladorTransferir };