const { atualizarConta } = require('../dados/contas');
const cpfCheck = require('cpf-check');

const ControladorAtualizarConta = async (req, res) => {
    try {
        const { idConta } = req.params;
        const { nomeTitular, cpfTitular, status } = req.body;

        if (status !== undefined && status !== "" && status !== "ativa" && status !== "suspensa" && status !== "encerrada") {
            return res.status(400).json({ error: 'Status inválido' });
        }

        if (cpfTitular !== undefined && cpfTitular !== "" && !cpfCheck.validate(cpfTitular)) {
            return res.status(400).json({ error: 'CPF invalido' });
        }

        const contaAtualizada = await atualizarConta(idConta, nomeTitular, cpfTitular, status, undefined);

        res.status(200).json(contaAtualizada);
    } catch (error) {
        res.status(500).json({ mensagem: error.message });
    }
};

module.exports = { ControladorAtualizarConta };